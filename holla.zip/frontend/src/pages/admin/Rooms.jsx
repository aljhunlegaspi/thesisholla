import * as React from 'react';
import Box from '@mui/material/Box';
import { DataGrid } from '@mui/x-data-grid';
import { Container } from '@mui/material';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import { getGoals, reset } from '../../features/goals/goalSlice'
import Spinner from '../../components/Spinner';
import AddRoom from '../../components/CreateRoom';
// {
//   field: 'fullName',
//   headerName: 'Full name',
//   description: 'This column has a value getter and is not sortable.',
//   sortable: false,
//   width: 160,
//   valueGetter: (params) =>
//     `${params.row.firstName || ''} ${params.row.lastName || ''}`,
// },




export default function RoomsTable() {

  const navigate = useNavigate()
  const dispatch = useDispatch()

  const { user } = useSelector((state) => state.auth)
  const { goals, isLoading, isError, message } = useSelector(
    (state) => state.goals
  )

  useEffect(() => {
    if (isError) {
      console.log(message)
    }

    if (!user) {
      navigate('/login')
    }

    dispatch(getGoals())

    return () => {
      dispatch(reset())
    }
  }, [user, navigate, isError, message, dispatch])

  if (isLoading) {
    return <Spinner />
  }



  return (
    <Container className="d-flex justify-content-around mt-3">
      <Container className="col-8">
        <Box className="d-flex flex-row gap-3">
          <Card sx={{ maxWidth: 200, width: 150, maxHeight: 100, height: 100 }}>
            <CardActionArea sx={{ maxWidth: 200, maxHeight: 100, height: 100 }}>
              <CardContent>
                <Typography gutterBottom variant="h5" component="div" className="text-center">
                  35
                </Typography>
                <Typography variant="body2" color="text.secondary" className="text-center">
                  Total Rooms
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
          {/* Clean Rooms */}
          <Card sx={{ maxWidth: 200, width: 150, maxHeight: 100, height: 100 }}>
            <CardActionArea sx={{ maxWidth: 200, maxHeight: 100, height: 100 }}>
              <CardContent>
                <Typography gutterBottom variant="h5" component="div" className="text-center">
                  18
                </Typography>
                <Typography variant="body2" color="text.secondary" className="text-center">
                  Clean Rooms
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
          {/* Dirty Rooms */}
          <Card sx={{ maxWidth: 200, width: 150, maxHeight: 100, height: 100 }}>
            <CardActionArea sx={{ maxWidth: 200, maxHeight: 100, height: 100 }}>

                <Typography gutterBottom variant="h5" component="div" className="text-center">
                  17
                </Typography>
                <Typography variant="body2" color="text.secondary" className="text-center">
                  Dirty Rooms
                </Typography>

            </CardActionArea>
          </Card>

        </Box>

        <Box className="mt-3 border" sx={{ height: 400, width: '130vh' }}>
          <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">RoomNo</th>
                <th scope="col">Room Type</th>
                <th scope="col">Rate</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
            </tbody>
          </table>
        </Box>
        <AddRoom/>
      </Container>


    </Container>
  );
}